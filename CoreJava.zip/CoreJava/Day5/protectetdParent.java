package Basics;

public class protectetdParent 
{
	protected static int a=50;

}
