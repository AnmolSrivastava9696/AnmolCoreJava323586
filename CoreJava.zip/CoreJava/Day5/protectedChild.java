package Basics;

public class protectedChild extends protectetdParent 
{
	
public static void main(String args[])
{
	
	
	System.out.println(protectetdParent.a);
}
}
