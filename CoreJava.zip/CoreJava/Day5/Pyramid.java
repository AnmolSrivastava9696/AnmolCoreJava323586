package Basics;

public class Pyramid 
{

	
}
