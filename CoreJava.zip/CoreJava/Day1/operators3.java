package Basics;

public class operators3 
{
public static void main(String args[])
{
	int c=5;
	int a=10;
	int b=20;
	System.out.println(a<b);
	System.out.println(b>c);
}
}
