package Basics;

public class Operators 
{
public static void main(String args[])
{
	int a=32;
	int x,y;
	x=a/10;
	y=a%10;
	System.out.println(x);
	System.out.println(y);
}	

}
