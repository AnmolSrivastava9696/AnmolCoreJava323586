package Basics;

public class Pattern 
{
	public static void main(String args[])
	{
		int n=9;
		for(int i=1;i<4;i++)
		{
			
		}
	}
	

}
