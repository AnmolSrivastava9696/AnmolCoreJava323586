package Basics;

public class Elephant {

}
