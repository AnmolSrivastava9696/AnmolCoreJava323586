package Basics;

public class SwitchExample 
{
	public static void main(String args[])
	{
		int n=12;
		switch(n)
		{
		
		case 7:
			System.out.println("valueis 7");
		case 5:
			System.out.println("value is 5");
			break;
		case 12:
			System.out.println("value is 12");
		default:
				System.out.println("default case is executed");
				
		}
	}

}
