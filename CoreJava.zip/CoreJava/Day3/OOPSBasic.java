package Basics;

public class OOPSBasic 
{
	String brand;
	float length;
	String color;
	float breadth;
	public void displayDetails()
	{
		System.out.println("Color : "+color+" length: "+length +" breadth: " +breadth+"brand: "+brand );
	}
	public void call()
	{
		System.out.println("Mobile is Calling");
	}
	public void message()
	{
		System.out.println("Mobile is sending message");
	}

}
