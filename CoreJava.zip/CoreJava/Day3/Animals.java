package Basics;

public class Animals {

}
