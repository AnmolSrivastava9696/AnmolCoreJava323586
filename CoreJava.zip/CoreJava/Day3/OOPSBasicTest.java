package Basics;

public class OOPSBasicTest 
{
	public static void main(String args[])
	{
		OOPSBasic samsung=new OOPSBasic();
		samsung.brand="samsung";
		samsung.length=6.2f;
		samsung.color="black";
		samsung.breadth=3.2f;
		samsung.displayDetails();
		samsung.call();
		samsung.message();
	}

}
