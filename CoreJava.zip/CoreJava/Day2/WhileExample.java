package Basics;

public class WhileExample
{
	public static void main(String args[])
	{
		int sum=0;
		for(int i=10;i<30;i++)
		{
			int rem=i%3;
			if(rem==0)
			{
				System.out.println();
			}
		}
	}

}
