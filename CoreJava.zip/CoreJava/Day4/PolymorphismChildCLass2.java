package Basics;

public class PolymorphismChildCLass2 extends PolymorphismBaseClass 
{
public float getROI()
{
	return 9.0f;
	}
}
