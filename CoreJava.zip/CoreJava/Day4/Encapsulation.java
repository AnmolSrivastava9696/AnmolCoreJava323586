package Basics;

public class Encapsulation 
{
private int account_no;
private int acc_bal;
public int getAccount_no() {
	return account_no;
}
public void setAccount_no(int account_no) {
	this.account_no = account_no;
}
public int getAcc_bal() {
	return acc_bal;
}
public void setAcc_bal(int acc_bal) {
	this.acc_bal = acc_bal;
}
}
