package Basics;

public class PolymorphismBaseClass 
{
	public float getROI()
	{
		return 0f;
	}

}
