package Basics;

import java.util.Scanner;

public class MultiplicationTable 
{
	public static void main(String args[])
	{
		int i;
		int j=4;
		for(i=5;i<10;i++)
		{
			
			
				System.out.println(i+" * "+j+" = "+(i*j));
				j=j+2;
				
			
		}
	}

}
