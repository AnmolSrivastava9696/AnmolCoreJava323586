package Basics;

public class PolymorphismChildClass1 extends PolymorphismBaseClass 
{
	public float getROI()
	{
		return 6.0f;
	}

}
