package Basics;
import java.util.*;
public class ArrayListExample 
{
	public static void main(String args[])
	{
		
		ArrayList<String> a=new ArrayList<>();
	
		a.add("Anmol");
		a.add("Anant");
		a.add("Prachi");
		a.add("Shagun");
		for(String s : a)
		{
			System.out.print(s+" ");
		}
		
		
		
		
	}

	
	
}
