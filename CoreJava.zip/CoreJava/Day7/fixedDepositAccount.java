package Asssignments;

public class fixedDepositAccount extends account
{
	
	public fixedDepositAccount(	int accountno,int accountbal,double int_rate,String accountname)
	 {
		this.accountname=accountname;
		this.accountbal=accountbal;
		this.accountno=accountno;
		this.int_rate=int_rate;
	}
}
